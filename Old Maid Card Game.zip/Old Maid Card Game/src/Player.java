import java.util.*;

public class Player {
    private int playerIndex;
    private List<Card> hand;

    public Player(int playerIndex) {
        this.playerIndex = playerIndex;
        hand = new ArrayList<>();
    }

    public int getPlayerIndex() {
        return playerIndex;
    }

    public List<Card> getHand() {
        return hand;
    }
}