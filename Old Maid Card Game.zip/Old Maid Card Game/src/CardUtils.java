import java.util.*;
public class CardUtils {

    public static void discardMatchingPairs(List<Card> hand) {
        Set<Card> pairs = new HashSet<>();
        Iterator<Card> iterator = hand.iterator();

        while (iterator.hasNext()) {
            Card card1 = iterator.next();
            for (Card card2 : hand) {
                if (card1 != card2 && isMatchingPair(card1, card2)) {
                    pairs.add(card1);
                    pairs.add(card2);
                }
            }
        }

        hand.removeAll(pairs);
    }



    public static boolean isMatchingPair(Card card1, Card card2) {
        return card1.getValue().equals(card2.getValue()) &&
                ((card1.getSuit().equals("♠") && card2.getSuit().equals("♣")) ||
                        (card1.getSuit().equals("♣") && card2.getSuit().equals("♠")) ||
                        (card1.getSuit().equals("♦") && card2.getSuit().equals("♥")) ||
                        (card1.getSuit().equals("♥") && card2.getSuit().equals("♦")));
    }



}
