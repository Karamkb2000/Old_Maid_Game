import java.util.*;

public class CardGame {
    private static final String[] VALUES = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    private static final String[] SUITS = {"♠", "♣", "♦", "♥"};
    private static final String JOKER = "Joker";

    private List<Player> players;
    private Deck deck;

    public CardGame(int numPlayers) {
        players = new ArrayList<>();
        for (int i = 0; i < numPlayers; i++) {
            players.add(new Player(i));
        }
        deck = new Deck(VALUES, SUITS);
        deck.addCard(new Card(JOKER, ""));
        deck.shuffle();
    }

    private void dealCards() {
        int totalCards = 53; // Including the Joker
        int numPlayers = players.size();
        int cardsPerPlayer = totalCards / numPlayers;

        // Distribute cards evenly to all players except the last one
        for (int i = 0; i < numPlayers - 1; i++) {
            Player player = players.get(i);
            for (int j = 0; j < cardsPerPlayer; j++) {
                Card card = deck.drawCard();
                if (card != null) {
                    player.getHand().add(card);
                }
            }
        }

        // Distribute remaining cards to the last player
        Player lastPlayer = players.get(numPlayers - 1);
        while (!deck.isEmpty()) {
            Card card = deck.drawCard();
            if (card != null) {
                lastPlayer.getHand().add(card);
            }
        }
    }

    private void discardMatchingPairs(List<Card> hand) {
        CardUtils.discardMatchingPairs(hand); // Use the utility method
    }
    private void printGameState() {
        for (Player player : players) {
            System.out.print("Player " + (player.getPlayerIndex() + 1) + " hand: " + player.getHand());
            System.out.println();
        }
    }

    public void playGame() {
        dealCards();
        printGameState();

        List<Player> activePlayers = new ArrayList<>(players);
        int currentPlayerIndex = 0;

        while (activePlayers.size() > 1) {
            Player currentPlayer = activePlayers.get(currentPlayerIndex);
            Player prevPlayer = activePlayers.get((currentPlayerIndex - 1 + activePlayers.size()) % activePlayers.size());

            synchronized (prevPlayer) {
                synchronized (currentPlayer) {
                    if (!currentPlayer.getHand().isEmpty() && !prevPlayer.getHand().isEmpty()) {
                        int randomIndex = new Random().nextInt(prevPlayer.getHand().size());
                        Card drawnCard = prevPlayer.getHand().remove(randomIndex);
                        currentPlayer.getHand().add(drawnCard);

                        System.out.println("Player " + (currentPlayer.getPlayerIndex() + 1) +
                                " drew " + drawnCard + " from Player " + (prevPlayer.getPlayerIndex() + 1));

                        discardMatchingPairs(currentPlayer.getHand());

                        printGameState();
                        System.out.println("==================================");
                    }
                }
            }

            try {
                Thread.sleep(100); // Simulate some delay between player moves
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (currentPlayer.getHand().isEmpty()) {
                activePlayers.remove(currentPlayer);
                if (currentPlayerIndex >= activePlayers.size()) {
                    currentPlayerIndex = 0;
                }
            } else {
                currentPlayerIndex = (currentPlayerIndex + 1) % activePlayers.size();
            }
        }

        Player loser = activePlayers.get(0);
        System.out.println("Player " + (loser.getPlayerIndex() + 1) + " lost! The remaining players:");
        printGameState();
    }

    public static void main(String[] args) {

        int numPlayers = 4;
        CardGame cardGame = new CardGame(numPlayers);
        cardGame.playGame();
    }
}